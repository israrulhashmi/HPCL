#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  4 16:07:39 2025

@author: rahul
"""

import xgboost as xgb
import numpy as np

def predict_from_xgboost(X_input):
    """
    Load an XGBoost model from a JSON file and return predictions.

    Parameters:
    - json_model_path (str): Path to the saved XGBoost JSON model.
    - X_input (numpy array or pandas DataFrame): Input data for prediction.

    Returns:
    - numpy array: Predicted values
    """
    # Load the trained model for Tensile strength at yield
    model_TSY = xgb.XGBRegressor()
    model_TSY.load_model('xgboost_regressor_1st_col.json')

    # Make predictions of Tensile strength at yield
    predictions_TSY = model_TSY.predict(X_input)
    
    # Load the trained model for Elongation at yield
    model_EY = xgb.XGBRegressor()
    model_EY.load_model('xgboost_regressor_2nd_col.json')
    
    # Make predictions for Elongation at yield
    predictions_EY = model_EY.predict(X_input)
    
    
    # Load the trained model for Elongation at yield
    model_UTS = xgb.XGBRegressor()
    model_UTS.load_model('xgboost_regressor_3rd_col.json')
    
    # Make predictions
    predictions_UTS = model_UTS.predict(X_input)
    
    
    # Load the trained model for Elongation at Break
    model_EB = xgb.XGBRegressor()
    model_EB.load_model('xgboost_regressor_4th_col.json')
    
    # Make predictions
    predictions_EB = model_EB.predict(X_input)
    
    
    
    
    return predictions_TSY, predictions_EY, predictions_UTS, predictions_EB
