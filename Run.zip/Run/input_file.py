#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The folder contains an ML model to predict mechanical properties of polypropylene-fiber
composites. The script is developed at IIT Madras using open-source libraries. The
developers are Rahul Karmakar, Israrul Hashmi, and Tarak Patra. The data are provided
by the HPCL Green R&D Center. The HPCL Green R&D center is authorized to use this
model. It should not be used by and shared with any third party. Following is the
procedure to install and execute an ML model

@author: Rahul Karmakar, Israrul H Hashmi, Tarak Patra
"""

import numpy as np
import pandas as pd
from prediction_function import predict_from_xgboost  # Replace 'your_module' with actual filename


file = pd.read_excel('datafile.xlsx')

# Load test data (make sure it's in the same format as training)

input_data = file[['PP_H200MA','PP_H350FG','PP_B120MA','PP_C320MN','GF','MAPP','CF']]


col_sum = np.zeros(input_data.shape[0])
# Loop through each row to sum its values
for i in range(input_data.shape[0]):
    col_sum[i] = np.sum(input_data.iloc[i], axis=0)  # Summing the row
    if col_sum[i] != 1:
        raise ValueError(f"Data file has a problem: Row {i} does not sum to 1 (actual sum: {col_sum[i]}). All rows should sum to 1.")
        
print("All rows sum to 1. Continuing with the process...")

# Load test data (make sure it's in the same format as training) this is just for demo
feature_values = np.array([0.58,0,0,0,0.4,0.02,0])  # Example input
feature_values = feature_values.reshape(1,len(feature_values))

# Call the function and get predictions
predictions = predict_from_xgboost(input_data)

print(predictions)

#%% save the output
output_cols = 4
output = np.zeros((input_data.shape[0],output_cols))

for tot in range(input_data.shape[0]):
    for val in range(output_cols):
        output[tot,val] = predictions[val][tot]
        
# Define column headers
headers = "Tensile Strength at Yield (MPa), Elongation at yield (%), Ultimate Tensile Strength (MPa), Elongation at  break (%)"        
# Save to a text file
np.savetxt("output.txt", output, header=headers,fmt="%.5f")  # Saves with 5 decimal places
        
